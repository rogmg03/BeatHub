package Json;

import java.io.File;

public class TestConvert{
	static File jsonFile1 = new File("example_1.json");
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student = new Student();
		student.setNumber(2016072504);
		student.setName("Luis");
		student.setGrade(80);
		String jsonStudent = Utility.ConvertJavaToJson(student);
		System.out.println(jsonStudent);
		System.out.println("=================");
		Student stu = Utility.ConvertJsonToJava(jsonStudent, Student.class);
		System.out.println(stu.getName() + " " + stu.getGrade() + " " + stu.getNumber());
	}

}
